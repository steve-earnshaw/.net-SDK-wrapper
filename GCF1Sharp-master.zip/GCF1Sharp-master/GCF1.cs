﻿using System;
using System.Runtime.InteropServices;

public static class GCF1Sharp
{
    /*
        GCF OPTIONS
     */

    /// GCF1_OPT_NONE -> 0x0000
    public const int GCF1_OPT_NONE = 0;

    /// GCF1_OPT_DL_FORCE_FULLDOWNLOAD -> 0x0100
    public const int GCF1_OPT_DL_FORCE_FULLDOWNLOAD = 256;

    /// GCF1_OPT_CHECK_EMBEDDED_URL -> 0x00000001
    public const int GCF1_OPT_CHECK_EMBEDDED_URL = 1;

    /// GCF1_OPT_CHECK_DEFAULT_MATCHING -> 0x00000000
    public const int GCF1_OPT_CHECK_DEFAULT_MATCHING = 0;

    /// GCF1_OPT_CHECK_LONGEST_MATCHING -> 0x00000100
    public const int GCF1_OPT_CHECK_LONGEST_MATCHING = 256;

    /// GCF1_OPT_CHECK_CASCADE_MATCHING -> 0x00000200
    public const int GCF1_OPT_CHECK_CASCADE_MATCHING = 512;

    /// GCF1_OPT_CHECK_DOMAINONLY_MATCHING -> 0x00000800
    public const int GCF1_OPT_CHECK_DOMAINONLY_MATCHING = 2048;

    /// GCF1_OPT_CHECK_IAB_DEFAULT_MATCHING -> 0x10000000
    public const int GCF1_OPT_CHECK_IAB_DEFAULT_MATCHING = 268435456;

    /// GCF1_OPT_CHECK_IAB_CASCADE_MATCHING -> 0x10000200
    public const int GCF1_OPT_CHECK_IAB_CASCADE_MATCHING = 268435968;

    /// GCF1_OPT_CHECK_IAB_DOMAINONLY_MATCHING -> 0x10000800
    public const int GCF1_OPT_CHECK_IAB_DOMAINONLY_MATCHING = 268437504;

    /// GCF1_OPT_CHECK_MC_DEFAULT_MATCHING -> 0x01000000
    public const int GCF1_OPT_CHECK_MC_DEFAULT_MATCHING = 16777216;

    /// GCF1_OPT_CHECK_MC_CASCADE_MATCHING -> 0x01000200
    public const int GCF1_OPT_CHECK_MC_CASCADE_MATCHING = 16777728;

    /// GCF1_OPT_CHECK_MC_DOMAINONLY_MATCHING -> 0x01000800
    public const int GCF1_OPT_CHECK_MC_DOMAINONLY_MATCHING = 16779264;

    /// GCF1_CHECK2_FLAG_ENABLE -> 0x01
    public const int GCF1_CHECK2_FLAG_ENABLE = 1;

    /// GCF1_CHECK2_FLAG_CHECKED -> 0x02
    public const int GCF1_CHECK2_FLAG_CHECKED = 2;

    /// GCF1_CHECK2_FLAG_HASMORE -> 0x04
    public const int GCF1_CHECK2_FLAG_HASMORE = 4;

    /// GCF1_CHECK2_FLAG_HASLEFT -> 0x08
    public const int GCF1_CHECK2_FLAG_HASLEFT = 8;

    /// GCF1_CHECK2_FLAG_HASRIGHT -> 0x10
    public const int GCF1_CHECK2_FLAG_HASRIGHT = 16;

    /// GCF1_CHECK2_FLAG_GENERIC -> 0x20
    public const int GCF1_CHECK2_FLAG_GENERIC = 32;

    /// GCF1_CHECK3_FLAG_ENABLE -> 0x0100
    public const int GCF1_CHECK3_FLAG_ENABLE = 256;

    /// GCF1_CHECK3_FLAG_EMBEDDED_URL -> 0x0200
    public const int GCF1_CHECK3_FLAG_EMBEDDED_URL = 512;

    /// GCF1_CHECK3_FLAG_USRDB -> 0x0400
    public const int GCF1_CHECK3_FLAG_USRDB = 1024;

    /// GCF1_CHECK3_FLAG_HASREPUTATION -> 0x0800
    public const int GCF1_CHECK3_FLAG_HASREPUTATION = 2048;

    /// GCF1_CHECK3_FLAG_KWDB -> 0x0001
    public const int GCF1_CHECK3_FLAG_KWDB = 1;

    /// GCF1_CHECK3_FLAG_CACHEDB -> 0x0002
    public const int GCF1_CHECK3_FLAG_CACHEDB = 2;

    /// GCF1_CHECK3_FLAG_LOCALDB -> 0x0004
    public const int GCF1_CHECK3_FLAG_LOCALDB = 4;

    /// GCF1_CHECK3_FLAG_CLOUDDB -> 0x0008
    public const int GCF1_CHECK3_FLAG_CLOUDDB = 8;

    /// GCF1_OPT_CHECK3_EMBEDDED_URL -> 0x00000001
    public const int GCF1_OPT_CHECK3_EMBEDDED_URL = 1;

    /// GCF1_OPT_CHECK3_DEFAULT_MATCHING -> 0x00000000
    public const int GCF1_OPT_CHECK3_DEFAULT_MATCHING = 0;

    /// GCF1_OPT_CHECK3_LONGEST_MATCHING -> 0x00000100
    public const int GCF1_OPT_CHECK3_LONGEST_MATCHING = 256;

    /// GCF1_OPT_CHECK3_CASCADE_MATCHING -> 0x00000200
    public const int GCF1_OPT_CHECK3_CASCADE_MATCHING = 512;

    /// GCF1_OPT_CHECK3_SIMPLE_MATCHING -> 0x00000400
    public const int GCF1_OPT_CHECK3_SIMPLE_MATCHING = 1024;

    /// GCF1_OPT_CHECK3_DOMAINONLY_MATCHING -> 0x00000800
    public const int GCF1_OPT_CHECK3_DOMAINONLY_MATCHING = 2048;

    /// GCF1_OPT_CHECK3_IAB_DEFAULT_MATCHING -> 0x10000000
    public const int GCF1_OPT_CHECK3_IAB_DEFAULT_MATCHING = 268435456;

    /// GCF1_OPT_CHECK3_IAB_LONGEST_MATCHING -> 0x10000100
    public const int GCF1_OPT_CHECK3_IAB_LONGEST_MATCHING = 268435712;

    /// GCF1_OPT_CHECK3_IAB_CASCADE_MATCHING -> 0x10000200
    public const int GCF1_OPT_CHECK3_IAB_CASCADE_MATCHING = 268435968;

    /// GCF1_OPT_CHECK3_IAB_SIMPLE_MATCHING -> 0x10000400
    public const int GCF1_OPT_CHECK3_IAB_SIMPLE_MATCHING = 268436480;

    /// GCF1_OPT_CHECK3_IAB_DOMAINONLY_MATCHING -> 0x10000800
    public const int GCF1_OPT_CHECK3_IAB_DOMAINONLY_MATCHING = 268437504;

    /// GCF1_OPT_CHECK3_MC_DEFAULT_MATCHING -> 0x01000000
    public const int GCF1_OPT_CHECK3_MC_DEFAULT_MATCHING = 16777216;

    /// GCF1_OPT_CHECK3_MC_LONGEST_MATCHING -> 0x01000100
    public const int GCF1_OPT_CHECK3_MC_LONGEST_MATCHING = 16777472;

    /// GCF1_OPT_CHECK3_MC_CASCADE_MATCHING -> 0x01000200
    public const int GCF1_OPT_CHECK3_MC_CASCADE_MATCHING = 16777728;

    /// GCF1_OPT_CHECK3_MC_SIMPLE_MATCHING -> 0x01000400
    public const int GCF1_OPT_CHECK3_MC_SIMPLE_MATCHING = 16778240;

    /// GCF1_OPT_CHECK3_MC_DOMAINONLY_MATCHING -> 0x01000800
    public const int GCF1_OPT_CHECK3_MC_DOMAINONLY_MATCHING = 16779264;

    /// GCF1_OPT_CHECK3_HYBRID_DEFAULT_MATCHING -> 0x03000000
    public const int GCF1_OPT_CHECK3_HYBRID_DEFAULT_MATCHING = 50331648;

    /// GCF1_OPT_CHECK3_HYBRID_LONGEST_MATCHING -> 0x03000100
    public const int GCF1_OPT_CHECK3_HYBRID_LONGEST_MATCHING = 50331904;

    /// GCF1_OPT_CHECK3_HYBRID_DEFAULT_LOCAL_MATCHING -> 0x03000003
    public const int GCF1_OPT_CHECK3_HYBRID_DEFAULT_LOCAL_MATCHING = 50331651;

    /// GCF1_OPT_CHECK3_HYBRID_DEFAULT_CLOUD_MATCHING -> 0x03000004
    public const int GCF1_OPT_CHECK3_HYBRID_DEFAULT_CLOUD_MATCHING = 50331652;

    /// GCF1_OPT_CHECK3_HYBRID_LONGEST_LOCAL_MATCHING -> 0x03000103
    public const int GCF1_OPT_CHECK3_HYBRID_LONGEST_LOCAL_MATCHING = 50331907;

    /// GCF1_OPT_CHECK3_HYBRID_LONGEST_CLOUD_MATCHING -> 0x03000104
    public const int GCF1_OPT_CHECK3_HYBRID_LONGEST_CLOUD_MATCHING = 50331908;

    /// GCF1_OPT_DBMNG_UPDATE_DEFAULT -> 0x00000007
    public const int GCF1_OPT_DBMNG_UPDATE_DEFAULT = 7;

    /// GCF1_OPT_DBMNG_UPDATE_NSDB -> 0x00000001
    public const int GCF1_OPT_DBMNG_UPDATE_NSDB = 1;

    /// GCF1_OPT_DBMNG_UPDATE_USRDB -> 0x00000002
    public const int GCF1_OPT_DBMNG_UPDATE_USRDB = 2;

    /// GCF1_OPT_DBMNG_UPDATE_KWDB -> 0x00000004
    public const int GCF1_OPT_DBMNG_UPDATE_KWDB = 4;

    /// GCF1_OPT_DBMNG_CLEAR_CACHEDB -> 0x00000010
    public const int GCF1_OPT_DBMNG_CLEAR_CACHEDB = 16;

    /*
        GCF ERROR CODES
     */

    
    /// GCF1_ERR_INTERNAL -> 0x00010007
    public const int GCF1_ERR_INTERNAL = 65543;
    
    /// GCF1_ERR_SHMASSIGNFAIL -> 0x00010008
    public const int GCF1_ERR_SHMASSIGNFAIL = 65544;
    
    /// GCF1_ERR_URLASSIGNFAIL -> 0x00010009
    public const int GCF1_ERR_URLASSIGNFAIL = 65545;
    
    /// GCF1_ERR_SHMRELEASEFAIL -> 0x00010010
    public const int GCF1_ERR_SHMRELEASEFAIL = 65552;
    
    /// GCF1_ERR_CHECKFAIL -> 0x00010011
    public const int GCF1_ERR_CHECKFAIL = 65553;
    
    /// GCF1_ERR_INVALIDURL -> 0x00010012
    public const int GCF1_ERR_INVALIDURL = 65554;
    
    /// GCF1_ERR_DBNOTREADY -> 0x00010013
    public const int GCF1_ERR_DBNOTREADY = 65555;
    
    /// GCF1_ERR_DL_HOSTNOTFOUND -> 0x00010014
    public const int GCF1_ERR_DL_HOSTNOTFOUND = 65556;
    
    /// GCF1_ERR_DL_CONNECTFAIL -> 0x00010015
    public const int GCF1_ERR_DL_CONNECTFAIL = 65557;
    
    /// GCF1_ERR_DL_WRITEFAIL -> 0x00010016
    public const int GCF1_ERR_DL_WRITEFAIL = 65558;
    
    /// GCF1_ERR_DL_BADSTATUS -> 0x00010017
    public const int GCF1_ERR_DL_BADSTATUS = 65559;
    
    /// GCF1_ERR_DL_BADRESPONSE -> 0x00010018
    public const int GCF1_ERR_DL_BADRESPONSE = 65560;
    
    /// GCF1_ERR_DL_BADLICENSE -> 0x00010019
    public const int GCF1_ERR_DL_BADLICENSE = 65561;
    
    /// GCF1_ERR_DL_SERVERERROR -> 0x00010020
    public const int GCF1_ERR_DL_SERVERERROR = 65568;
    
    /// GCF1_ERR_DL_DOWNLOADFAIL -> 0x00010021
    public const int GCF1_ERR_DL_DOWNLOADFAIL = 65569;
    
    /// GCF1_ERR_DL_BADFILE -> 0x00010022
    public const int GCF1_ERR_DL_BADFILE = 65570;
    
    /// GCF1_ERR_DL_OPENFAIL -> 0x00010023
    public const int GCF1_ERR_DL_OPENFAIL = 65571;
    
    /// GCF1_ERR_DL_READFAIL -> 0x00010024
    public const int GCF1_ERR_DL_READFAIL = 65572;
    
    /// GCF1_ERR_DL_SENDFAIL -> 0x00010025
    public const int GCF1_ERR_DL_SENDFAIL = 65573;
    
    /// GCF1_ERR_DL_XDELT3FAIL -> 0x00010026
    public const int GCF1_ERR_DL_XDELT3FAIL = 65574;
    
    /// GCF1_ERR_DBFILEOPENFAIL -> 0x00010027
    public const int GCF1_ERR_DBFILEOPENFAIL = 65575;
    
    /// GCF1_ERR_DBFILEINVALID -> 0x00010028
    public const int GCF1_ERR_DBFILEINVALID = 65576;
    
    /// GCF1_ERR_SHMCREATEFAIL -> 0x00010029
    public const int GCF1_ERR_SHMCREATEFAIL = 65577;
    
    /// GCF1_ERR_SHMDELETEFAIL -> 0x00010030
    public const int GCF1_ERR_SHMDELETEFAIL = 65584;
    
    /// GCF1_ERR_UPDATEFAIL -> 0x00010031
    public const int GCF1_ERR_UPDATEFAIL = 65585;
    
    /// GCF1_ERR_RELOADFAIL -> 0x00010032
    public const int GCF1_ERR_RELOADFAIL = 65586;
    
    /// GCF1_ERR_INVALIDPARAMETER -> 0x00010033
    public const int GCF1_ERR_INVALIDPARAMETER = 65587;
    
    /// GCF1_ERR_FILECREATEFAIL -> 0x00010034
    public const int GCF1_ERR_FILECREATEFAIL = 65588;
    
    /// GCF1_ERR_DL_XDELTAFAIL -> 0x00010035
    public const int GCF1_ERR_DL_XDELTAFAIL = 65589;
    
    /// GCF1_ERR_DL_CHECKMD5FAIL -> 0x00010036
    public const int GCF1_ERR_DL_CHECKMD5FAIL = 65590;
    
    /// GCF1_ERR_DL_REMOVEFAIL -> 0x00010037
    public const int GCF1_ERR_DL_REMOVEFAIL = 65591;
    
    /// GCF1_ERR_USRDB_OPENFAIL -> 0x00010038
    public const int GCF1_ERR_USRDB_OPENFAIL = 65592;
    
    /// GCF1_ERR_USRDB_WRITEFAIL -> 0x00010039
    public const int GCF1_ERR_USRDB_WRITEFAIL = 65593;
    
    /// GCF1_ERR_USRDB_MAXCOUNT -> 0x0001003A
    public const int GCF1_ERR_USRDB_MAXCOUNT = 65594;
    
    /// GCF1_ERR_USRDB_INVALIDURL -> 0x0001003B
    public const int GCF1_ERR_USRDB_INVALIDURL = 65595;
    
    /// GCF1_ERR_USRDB_INVALIDCATEGORY -> 0x0001003D
    public const int GCF1_ERR_USRDB_INVALIDCATEGORY = 65597;
    
    /// GCF1_ERR_USRDB_INVALIDGROUP -> 0x0001003E
    public const int GCF1_ERR_USRDB_INVALIDGROUP = 65598;
    
    /// GCF1_ERR_SOCKETFAIL -> 0x00020001
    public const int GCF1_ERR_SOCKETFAIL = 131073;
    
    /// GCF1_ERR_CONNECTFAIL -> 0x00020002
    public const int GCF1_ERR_CONNECTFAIL = 131074;
    
    /// GCF1_ERR_SENDFAIL -> 0x00020003
    public const int GCF1_ERR_SENDFAIL = 131075;
    
    /// GCF1_ERR_RECVFAIL -> 0x00020004
    public const int GCF1_ERR_RECVFAIL = 131076;
    
    /// GCF1_ERR_CONNECTTIMEOUT -> 0x00020005
    public const int GCF1_ERR_CONNECTTIMEOUT = 131077;
    
    /// GCF1_ERR_MAX_POOL -> 0x00020006
    public const int GCF1_ERR_MAX_POOL = 131078;
    
    /// GCF1_ERR_NOTIMPL -> 0x00030001
    public const int GCF1_ERR_NOTIMPL = 196609;
    
    /// GCF1_ERR_END -> 0x00000000
    public const int GCF1_ERR_END = 0;

    /*
        GCF STRUCTS
     */

    [System.Runtime.InteropServices.StructLayoutAttribute(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct category_result1_s
    {

        /// int
        public int count;

        /// int[10]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 10, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] category;

        /// int[10]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 10, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] category_secondary;

        /// int[10]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 10, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] category_security;
    }

    [System.Runtime.InteropServices.StructLayoutAttribute(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct iab_category_result1_s
    {

        /// int
        public int count;

        /// int[10]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 10, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] iab_t1_category;

        /// int[10]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 10, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] iab_t2_category;
    }

    [System.Runtime.InteropServices.StructLayoutAttribute(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct category_result3_s
    {

        /// int
        public int size;

        /// int
        public int count;

        /// int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] category;

        /// int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] reputation;

        /// int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] level;

        /// unsigned int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.U4)]
        public uint[] flag;

        /// int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] category_secondary;

        /// int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] category_security;
    }

    [System.Runtime.InteropServices.StructLayoutAttribute(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct iab_category_result3_s
    {

        /// int
        public int size;

        /// int
        public int count;

        /// int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] iab_t1_category;

        /// int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] iab_t2_category;

        /// int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] level;

        /// unsigned int[16]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = System.Runtime.InteropServices.UnmanagedType.U4)]
        public uint[] flag;
    }

    [System.Runtime.InteropServices.StructLayoutAttribute(System.Runtime.InteropServices.LayoutKind.Sequential)]
    public struct category_result_ex1_s
    {

        /// int
        public int count;

        /// int[10]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 10, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] category;

        /// int[10]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValArray, SizeConst = 10, ArraySubType = System.Runtime.InteropServices.UnmanagedType.I4)]
        public int[] rate;
    }

    [System.Runtime.InteropServices.StructLayoutAttribute(System.Runtime.InteropServices.LayoutKind.Sequential, CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
    public struct category_info_s
    {

        /// char[255]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValTStr, SizeConst = 255)]
        public string name;

        /// char[1024]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValTStr, SizeConst = 1024)]
        public string description;

        /// char[1024]
        [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.ByValTStr, SizeConst = 1024)]
        public string extra_info;
    }

    /*
        GCF Functions
     */

    /// Return Type: int
    ///config_path: char*
    ///option: int
    ///handle: HCTC*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_begin")]
    public static extern int gcf1_check_begin([System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string config_path, int option, ref System.IntPtr handle);


    /// Return Type: int
    ///handle: HCTC->void*
    ///option: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_end")]
    public static extern int gcf1_check_end(System.IntPtr handle, int option);


    /// Return Type: int
    ///handle: HCTC->void*
    ///option: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_reload")]
    public static extern int gcf1_check_reload(System.IntPtr handle, int option);


    /// Return Type: int
    ///handle: HCTC->void*
    ///url: char*
    ///option: int
    ///category_result: category_result1_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_url")]
    public static extern int gcf1_check_url(System.IntPtr handle, [System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string url, int option, ref category_result1_s category_result);


    /// Return Type: int
    ///handle: HCTC->void*
    ///url: char*
    ///option: int
    ///category_result: category_result3_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_url3")]
    public static extern int gcf1_check_url3(System.IntPtr handle, [System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string url, int option, ref category_result3_s category_result);


    /// Return Type: int
    ///handle: HCTC->void*
    ///url: char*
    ///option: int
    ///category_result: iab_category_result1_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_iab")]
    public static extern int gcf1_check_iab(System.IntPtr handle, [System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string url, int option, ref iab_category_result1_s category_result);


    /// Return Type: int
    ///handle: HCTC->void*
    ///url: char*
    ///option: int
    ///category_result: iab_category_result3_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_iab3")]
    public static extern int gcf1_check_iab3(System.IntPtr handle, [System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string url, int option, ref iab_category_result3_s category_result);


    /// Return Type: int
    ///handle: HCTC->void*
    ///version_string: char*
    ///version_length: int*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_dbversion")]
    public static extern int gcf1_check_dbversion(System.IntPtr handle, System.IntPtr version_string, ref int version_length);


    /// Return Type: int
    ///handle: HCTC->void*
    ///categories_list: int*
    ///categories_list_length: int*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_categories")]
    public static extern int gcf1_check_categories(System.IntPtr handle, int[] categories_list, ref int categories_list_length);


    /// Return Type: int
    ///handle: HCTC->void*
    ///category_id: int
    ///category_info: category_info_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_category_info")]
    public static extern int gcf1_check_category_info(System.IntPtr handle, int category_id, ref category_info_s category_info);


    /// Return Type: int
    ///handle: HCTC->void*
    ///reputations_list: int*
    ///reputations_list_length: int*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_reputations")]
    public static extern int gcf1_check_reputations(System.IntPtr handle, int[] reputations_list, ref int reputations_list_length);


    /// Return Type: int
    ///handle: HCTC->void*
    ///reputation_id: int
    ///reputation_info: category_info_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_reputation_info")]
    public static extern int gcf1_check_reputation_info(System.IntPtr handle, int reputation_id, ref category_info_s reputation_info);


    /// Return Type: int
    ///handle: HCTC->void*
    ///categories_list: int*
    ///categories_list_length: int*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_iab_t1_categories")]
    public static extern int gcf1_check_iab_t1_categories(System.IntPtr handle, int[] categories_list, ref int categories_list_length);


    /// Return Type: int
    ///handle: HCTC->void*
    ///category_id: int
    ///category_info: category_info_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_iab_t1_category_info")]
    public static extern int gcf1_check_iab_t1_category_info(System.IntPtr handle, int category_id, ref category_info_s category_info);


    /// Return Type: int
    ///handle: HCTC->void*
    ///categories_list: int*
    ///categories_list_length: int*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_iab_t2_categories")]
    public static extern int gcf1_check_iab_t2_categories(System.IntPtr handle, int[] categories_list, ref int categories_list_length);


    /// Return Type: int
    ///handle: HCTC->void*
    ///category_id: int
    ///category_info: category_info_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_iab_t2_category_info")]
    public static extern int gcf1_check_iab_t2_category_info(System.IntPtr handle, int category_id, ref category_info_s category_info);


    /// Return Type: int
    ///handle: HCTC->void*
    ///option: int
    ///domain: char*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_check_url3_clear_cachedb")]
    public static extern int gcf1_check_url3_clear_cachedb(System.IntPtr handle, int option, [System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string domain);


    /// Return Type: int
    ///config_path: char*
    ///option: int
    ///handle: HCTE*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_extra1_begin")]
    public static extern int gcf1_extra1_begin([System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string config_path, int option, ref System.IntPtr handle);


    /// Return Type: int
    ///handle: HCTE->void*
    ///option: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_extra1_end")]
    public static extern int gcf1_extra1_end(System.IntPtr handle, int option);


    /// Return Type: int
    ///handle: HCTE->void*
    ///contents: char*
    ///option: int
    ///category_result: category_result_ex1_s*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_extra1_check_contents")]
    public static extern int gcf1_extra1_check_contents(System.IntPtr handle, [System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string contents, int option, ref category_result_ex1_s category_result);


    /// Return Type: int
    ///config_path: char*
    ///option: int
    ///handle: HCTM*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_dbmng_begin")]
    public static extern int gcf1_dbmng_begin([System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string config_path, int option, ref System.IntPtr handle);


    /// Return Type: int
    ///handle: HCTM->void*
    ///option: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_dbmng_end")]
    public static extern int gcf1_dbmng_end(System.IntPtr handle, int option);


    /// Return Type: int
    ///handle: HCTM->void*
    ///option: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_dbmng_download")]
    public static extern int gcf1_dbmng_download(System.IntPtr handle, int option);


    /// Return Type: int
    ///handle: HCTM->void*
    ///option: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_dbmng_update")]
    public static extern int gcf1_dbmng_update(System.IntPtr handle, int option);


    /// Return Type: int
    ///handle: HCTM->void*
    ///option: int
    ///domain: char*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_dbmng_clear_cachedb")]
    public static extern int gcf1_dbmng_clear_cachedb(System.IntPtr handle, int option, [System.Runtime.InteropServices.InAttribute()] [System.Runtime.InteropServices.MarshalAsAttribute(System.Runtime.InteropServices.UnmanagedType.LPStr)] string domain);


    /// Return Type: int
    ///handle: HCTM->void*
    ///option: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_dbmng_open_usrdb")]
    public static extern int gcf1_dbmng_open_usrdb(System.IntPtr handle, int option);


    /// Return Type: int
    ///handle: HCTM->void*
    ///option: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_dbmng_close_usrdb")]
    public static extern int gcf1_dbmng_close_usrdb(System.IntPtr handle, int option);


    /// Return Type: int
    ///handle: HCTM->void*
    ///catid: int
    ///group: int
    ///url: char*
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_dbmng_add_usrdb")]
    public static extern int gcf1_dbmng_add_usrdb(System.IntPtr handle, int catid, int group, System.IntPtr url);


    /// Return Type: char*
    ///error_code: int
    [System.Runtime.InteropServices.DllImportAttribute(@"/usr/local/gcf1/lib/libgcf1_pt3.so", EntryPoint = "gcf1_error_string")]
    public static extern System.IntPtr gcf1_error_string(int error_code);

}