sudo env LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libssl.so.1.1:/lib/x86_64-linux-gnu/libz.so.1 dotnet run
