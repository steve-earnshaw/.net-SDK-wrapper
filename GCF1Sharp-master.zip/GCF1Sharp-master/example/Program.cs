﻿using System;
using System.ComponentModel;

namespace ZorusSWG
{
    class Program
    {
        static IntPtr HCTC;

        static void Main(string[] args)
        {
            GCF1Sharp.gcf1_check_begin("/usr/local/gcf1/etc/gcf1.conf", 0, ref HCTC);

            GCF1Sharp.category_result3_s category_result = new GCF1Sharp.category_result3_s();
            GCF1Sharp.gcf1_check_url3(HCTC, "https://www.google.com", GCF1Sharp.GCF1_OPT_CHECK3_HYBRID_DEFAULT_MATCHING, ref category_result);

            Console.WriteLine($"Cat ID: {category_result.category[0]}");

            GCF1Sharp.category_info_s category_info = new GCF1Sharp.category_info_s();
            GCF1Sharp.gcf1_check_category_info(HCTC, category_result.category[0], ref category_info);

            GCF1Sharp.gcf1_check_end(HCTC, 0);

            Console.WriteLine($"Got: {new string(category_info.name)}");
        }
    }
}
